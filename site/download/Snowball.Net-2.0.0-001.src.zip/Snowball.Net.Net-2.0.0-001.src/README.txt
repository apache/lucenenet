Lucene.Net Snowball.Net README file

INTRODUCTION

Please be advised that other then the English Stemmer, I have not tested or validated the any of the remaining stemmers provided in this release.  This task I can't do since it requires a test data and the understanding of the language of the provided stemmer.  Once those un-tested stemmers have been validated by volunteers who know the language, I will update this documentation to reflect this fact.

TEST STEMMERS:

	- English

UN-TESTED STEMMERS:

	- Danish
	- Dutch
	- Finnish
	- French
	- German2
	- German
	- Italian
	- Kp
	- Lovins
	- Norwegian
	- Porter
	- Portuguese
	- Russian
	- Spanish
	- Swedish
